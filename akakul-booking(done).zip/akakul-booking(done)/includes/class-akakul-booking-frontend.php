<?php

if (!defined('ABSPATH')) {
    exit;
}

class WooCommerce_Booking_Frontend {

    public function __construct() {
        add_action('woocommerce_after_add_to_cart_button', array($this, 'add_booking_button'));
        add_shortcode('woocommerce_booking_page', array($this, 'render_booking_page'));
        add_action('init', array($this, 'handle_booking_confirmation'));
    }
    // кнопка забронировать
    public function add_booking_button() {
        global $product;
        $booking_url = home_url('/bronirovanie/?product_id=' . $product->get_id());
        echo '<a href="' . esc_url($booking_url) . '" class="button" id="front_zabr" style="
            width: 150px;
            height: 30px;
            background-color: #FC7234;
            margin-left: 10px;
            text-decoration: none;
            display: inline-block; 
            color: white;
            text-align: center; 
            line-height: 30px; 
            border-radius: 5px; 
            font-size: 16px;">' . __('Забронировать', 'woocommerce-booking') . '</a>';
    }

    public function render_booking_page() {
        if (!isset($_GET['product_id'])) {
            return __('Товар не выбран.', 'woocommerce-booking');
        }
    
        $product_id = intval($_GET['product_id']);
        $product = wc_get_product($product_id);
    
        if (!$product) {
            return __('Товар не найден.', 'woocommerce-booking');
        }
    
        $error_message = '';
        if (isset($_POST['submit_booking'])) {
            $error_message = $this->handle_booking_request($product_id);
        }
    
        return $this->get_booking_form($product, $error_message);
    }

    private function get_booking_form($product, $error_message = '') {
        ob_start();
        ?>
        <div class="woocommerce-booking-form">
            <h2><?php echo __('Бронирование товара:', 'woocommerce-booking') . ' ' . $product->get_name(); ?></h2>
            
            <?php if ($error_message): ?>
                <div class="error-message" style="color:red;"><?php echo esc_html($error_message); ?></div>
            <?php endif; ?>
    
            <form method="post" id="booking-form" style="margin-bottom: 3rem;">
                <p class="form-row">
                    <label for="billing_first_name"><?php _e('Ф.И.О. родителя или представителя полностью', 'woocommerce-booking'); ?>
                    <abbr class="required" title="Required Field">*</abbr></label>
                    <input type="text" id="billing_first_name" name="billing_first_name" required>
                    <span class="error-message" id="billing_first_name_error" style="color:red;"></span>
                </p>
                <p class="form-row">
                    <label for="billing_child_name"><?php _e('Ф.И.О. ребенка полностью', 'woocommerce-booking'); ?>
                    <abbr class="required" title="Required Field">*</abbr></label>
                    <input type="text" id="billing_child_name" name="billing_child_name" required>
                    <span class="error-message" id="billing_child_name_error" style="color:red;"></span>
                </p>
                <p class="form-row">
                    <label for="billing_wooccm11"><?php _e('Дата рождения ребенка', 'woocommerce-booking'); ?>
                    <abbr class="required" title="Required Field">*</abbr></label>
                    <input type="date" id="billing_wooccm11" name="billing_wooccm11" required>
                    <span class="error-message" id="billing_wooccm11_error" style="color:red;"></span>
                </p>
                <p class="form-row">
                    <label for="billing_email"><?php _e('Email', 'woocommerce-booking'); ?>
                    <abbr class="required" title="Required Field">*</abbr></label>
                    <input type="email" id="billing_email" name="billing_email" required>
                    <span class="error-message" id="billing_email_error" style="color:red;"></span>
                </p>
                <p class="form-row">
                    <label for="billing_phone"><?php _e('Телефон', 'woocommerce-booking'); ?><abbr class="required" title="Required Field">*</abbr></label>
                    <input type="tel" id="billing_phone" name="billing_phone" required>
                    <span class="error-message" id="billing_phone_error" style="color:red;"></span>
                </p>
                <p class="form-row">
    <label for="privacy_policy">
        <input type="checkbox" id="privacy_policy" name="privacy_policy" required>
        <?php _e('Я согласен(на) на обработку персональных данных', 'woocommerce-booking'); ?>
        <abbr class="required" title="Required Field">*</abbr>
    </label>
    <span class="error-message" id="privacy_policy_error" style="color:red;"></span>
</p>
                <button type="submit" name="submit_booking" class="button alt" style="background-color:#FC7234"><?php _e('Забронировать', 'woocommerce-booking'); ?></button>
            </form>
        </div>
        
        <!-- Модальное окно -->
        <div id="booking-success-modal" style="display:none;">
            <div class="modal-content">
                <span class="close-button">&times;</span>
                <p><?php _e('Бронирование успешно завершено! Пожалуйста, проверьте вашу почту для подтверждения.
                 Если не увидели письма, то перейдите во вкладку "Спам".', 'woocommerce-booking'); ?></p>
            </div>
        </div>
        
        <style>
            #booking-form {
                background-color: #f9f9f9;
                border-radius: 8px;
                padding: 20px;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
                max-width: 600px;
                margin: 0 auto;
            }
            .form-row {
                margin-bottom: 15px;
            }
            label {
                display: block;
                font-weight: bold;
                margin-bottom: 5px;
                color: #333;
            }
            input[type="text"],
            input[type="date"],
            input[type="email"],
            input[type="tel"] {
                width: 100%;
                padding: 10px;
                border: 1px solid #ccc;
                border-radius: 4px;
                transition: border-color 0.3s;
            }
            input[type="text"]:focus,
            input[type="date"]:focus,
            input[type="email"]:focus,
            input[type="tel"]:focus {
                border-color: #007bff;
                outline: none;
            }
            .error-message {
                font-size: 12px;
                color: red;
                margin-top: 5px;
            }
            .button.alt {
                background-color: #007bff;
                color: #fff;
                border: none;
                padding: 10px 15px;
                border-radius: 4px;
                cursor: pointer;
                transition: background-color 0.3s;
                font-size: 16px;
            }
            .button.alt:hover {
                background-color: #0056b3;
            }
            #booking-success-modal {
                display: none; 
                position: fixed; 
                z-index: 1000; 
                left: 0;
                top: 0;
                width: 100%; 
                height: 100%; 
                overflow: auto; 
                background-color: rgba(0, 0, 0, 0.7);
                transition: opacity 0.3s ease;
            }
            .modal-content {
                background-color: #ffffff;
                margin: 10% auto; 
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
                width: 90%; 
                max-width: 500px;
                text-align: center;
                animation: fadeIn 0.3s;
            }
            .close-button {
                color: #aaa;
                float: right;
                font-size: 28px;
                font-weight: bold;
                cursor: pointer;
            }
            .close-button:hover,
            .close-button:focus {
                color: #ff4d4d;
                text-decoration: none;
            }
            p {
                font-size: 16px;
                color: #333;
                margin: 10px 0;
            }
            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }
            #privacy_policy {
        margin-right: 10px;
    }
    .form-row label[for="privacy_policy"] {
        display: flex;
        align-items: center;
        cursor: pointer;
    }
        </style>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const modal = document.getElementById('booking-success-modal');
                const closeButton = document.querySelector('.close-button');

                <?php if (isset($_POST['submit_booking']) && !$error_message): ?>
                    modal.style.display = 'block';
                <?php endif; ?>

                closeButton.addEventListener('click', function() {
                    modal.style.display = 'none';
                });

                window.addEventListener('click', function(event) {
                    if (event.target == modal) {
                        modal.style.display = 'none';
                    }
                });
            });
        </script>
        <?php
        return ob_get_clean();
    }
    
    private function generate_booking_token() {
        return bin2hex(random_bytes(16));
    }

    private function handle_booking_request($product_id) {
        $product = wc_get_product($product_id);

        if (!$product || !$product->is_in_stock()) {
            return __('Товар недоступен для бронирования.', 'woocommerce-booking');
        }

        // Проверка обязательных полей
        if (empty($_POST['billing_first_name']) || empty($_POST['billing_child_name']) || 
            empty($_POST['billing_wooccm11']) || empty($_POST['billing_email']) || 
            empty($_POST['billing_phone'])) {
            return __('Все поля обязательны для заполнения.', 'woocommerce-booking');
        }

        $parent_name = sanitize_text_field($_POST['billing_first_name']);
        $child_name  = sanitize_text_field($_POST['billing_child_name']);
        $child_bdate = sanitize_text_field($_POST['billing_wooccm11']);
        $email       = sanitize_email($_POST['billing_email']);
        $phone       = sanitize_text_field($_POST['billing_phone']);

        // Валидация ФИО
        if (!preg_match('/^[А-Яа-яёЁ\s]+$/u', $parent_name) || count(explode(' ', $parent_name)) < 3) {
            return __('ФИО родителя должно содержать только кириллицу и быть в формате "Фамилия Имя Отчество".', 'woocommerce-booking');
        }

        if (!preg_match('/^[А-Яа-яёЁ\s]+$/u', $child_name) || count(explode(' ', $child_name)) < 3) {
            return __('ФИО ребенка должно содержать только кириллицу и быть в формате "Фамилия Имя Отчество".', 'woocommerce-booking');
        }

        // Валидация телефона
        if (!preg_match('/^\+7 \(\d{3}\) \d{3} \d{2} \d{2}$/', $phone)) {
            return __('Неверный формат телефона.', 'woocommerce-booking');
        }

        // Валидация даты рождения
        if (empty($child_bdate)) {
            return __('Дата рождения ребенка обязательна.', 'woocommerce-booking');
        }


// Проверка чекбокса согласия
if (!isset($_POST['privacy_policy'])) {
    return __('Необходимо согласие на обработку персональных данных.', 'woocommerce-booking');
}

        $confirmation_token = $this->generate_booking_token();

        // Уменьшаем количество товара на складе
        $current_stock = $product->get_stock_quantity();
        if ($current_stock > 0) {
            $product->set_stock_quantity($current_stock - 1);
            $product->save();
        } else {
            return __('Товар закончился на складе.', 'woocommerce-booking');
        }

        $booking_id = $this->log_booking($product_id, $product->get_name(),
         $parent_name, $child_name, $child_bdate, $email, $phone, $confirmation_token);

        $subject = __('Подтверждение бронирования', 'woocommerce-booking');
        $confirmation_url = home_url('/confirm-booking/?token=' . $confirmation_token);
        $message = sprintf(
            __('Здравствуйте, %s!<br><br>Ваш товар "%s" успешно забронирован.<br><br>
            Пожалуйста, подтвердите бронирование в течение 24 часов, перейдя по ссылке: %s<br><br>
            После подтверждения вы получите ссылку для оплаты. Оплата должна быть произведена в течение 72 часов.', 'woocommerce-booking'),
            $parent_name,
            $product->get_name(),
            $confirmation_url
        );
        
        // Устанавливаем срок подтверждения (24 часа)
        global $wpdb;
        $table_name = $wpdb->prefix . 'woocommerce_bookings';
        $wpdb->update(
            $table_name,
            array('confirm_deadline' => time() + 24 * 3600),
            array('id' => $booking_id)
        );
        
        // Отправляем HTML-письмо
        add_filter('wp_mail_content_type', function() { return 'text/html'; });
        wp_mail($email, $subject, $message);
        remove_filter('wp_mail_content_type', 'set_html_content_type');

        return '';
    }

    private function log_booking($product_id, $product_name, 
    $parent_name, $child_name, $child_bdate, $email, $phone, $confirmation_token) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'woocommerce_bookings';

        return $wpdb->insert(
            $table_name,
            array(
                'product_id'          => $product_id,
                'product_name'        => $product_name,
                'parent_name'         => $parent_name,
                'child_name'          => $child_name,
                'child_bdate'         => $child_bdate,
                'email'               => $email,
                'phone'               => $phone,
                'confirmation_token'  => $confirmation_token,
                'booking_date'        => current_time('mysql'),
            )
        );
    }

    public function handle_booking_confirmation() {
        //проверка на наличие токена
    if (isset($_GET['token'])) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'woocommerce_bookings';
        $token = sanitize_text_field($_GET['token']);

        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE confirmation_token = %s",
            $token
        ));

        if ($booking) {
            // Проверяем наличие товара перед созданием заказа
            $product = wc_get_product($booking->product_id);
            if (!$product || !$product->is_in_stock()) {
                $subject = __('Бронирование отменено - товар недоступен', 'woocommerce-booking');
                $message = sprintf(
                    __('Здравствуйте, %s!<br><br>К сожалению, ваш забронированный товар "%s" больше недоступен,
                     и ваше бронирование было отменено.', 'woocommerce-booking'),
                    $booking->parent_name,
                    $booking->product_name
                );
                
                add_filter('wp_mail_content_type', function() { return 'text/html'; });
                wp_mail($booking->email, $subject, $message);
                remove_filter('wp_mail_content_type', 'set_html_content_type');
                
                $wpdb->delete($table_name, array('id' => $booking->id));
                
                wp_die(
                    __('К сожалению, товар больше недоступен. Бронирование отменено.', 'woocommerce-booking'), 
                    __('Ошибка', 'woocommerce-booking'),
                    array('response' => 404)
                );
            }

            // Обновляем статус бронирования
            $wpdb->update(
                $table_name,
                array(
                    'is_confirmed' => 1,
                    'payment_deadline' => time() + 72 * 3600
                ),
                array('id' => $booking->id)
            );

            // Создаем заказ WooCommerce
            $order = wc_create_order();
            $order->add_product($product, 1);
            
            // Устанавливаем данные покупателя
            $order->set_billing_email($booking->email);
            $order->set_billing_first_name($booking->parent_name);
            $order->set_billing_phone($booking->phone);
            
            $order->calculate_totals();
            $order->update_status('pending', __('Ожидает оплаты', 'woocommerce-booking'));
            
            // Сохраняем ID заказа
            $wpdb->update(
                $table_name,
                array('order_id' => $order->get_id()),
                array('id' => $booking->id)
            );
            
            // Отправляем письмо со ссылкой на оплату
            $payment_url = $order->get_checkout_payment_url();
            $subject = __('Ваше бронирование подтверждено - ссылка для оплаты', 'woocommerce-booking');
            $message = sprintf(
                __('Здравствуйте, %s!<br><br>Ваше бронирование товара "%s" подтверждено.<br><br>
                Для завершения бронирования, пожалуйста, оплатите заказ в течение 72 часов по ссылке: %s<br><br>
                Если вы не оплатите заказ в течение этого времени, бронирование будет автоматически отменено.', 'woocommerce-booking'),
                $booking->parent_name,
                $product->get_name(),
                $payment_url
            );
            
            add_filter('wp_mail_content_type', function() { return 'text/html'; });
            wp_mail($booking->email, $subject, $message);
            remove_filter('wp_mail_content_type', 'set_html_content_type');

            wp_die(
                __('Бронирование успешно подтверждено! На ваш email отправлена ссылка для оплаты.', 'woocommerce-booking'), 
                __('Подтверждение бронирования', 'woocommerce-booking'),
                array('response' => 200)
            );
        } else {
            wp_die(
                __('Недействительный токен подтверждения.', 'woocommerce-booking'), 
                __('Ошибка', 'woocommerce-booking'),
                array('response' => 404)
            );
        }
    }
}
}

new WooCommerce_Booking_Frontend();


