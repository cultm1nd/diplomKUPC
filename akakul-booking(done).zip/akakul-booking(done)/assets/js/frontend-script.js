jQuery(document).ready(function($) {
    // Маска для телефона
    $('#billing_phone').mask('+7 (000) 000 00 00');

    // Блокировка ввода не кириллических символов в поля ФИО
    $('#billing_first_name, #billing_child_name').on('keypress', function(e) {
        const char = String.fromCharCode(e.which);
        if (!/^[А-Яа-яЁё\s]$/.test(char)) {
            e.preventDefault(); // Блокируем ввод
        }
    });

    // Валидация формы
    $('#booking-form').on('submit', function(e) {
        let isValid = true;

        // Валидация ФИО родителя
        const parentName = $('#billing_first_name').val().trim();
        if (!/^[А-Яа-яёЁ\s]+$/.test(parentName) || parentName.split(' ').length < 3) {
            $('#billing_first_name_error').text('Ф.И.О. родителя должно содержать только кириллицу и быть в формате "Фамилия Имя Отчество".');
            isValid = false;
        } else {
            $('#billing_first_name_error').text('');
        }

        // Валидация ФИО ребенка
        const childName = $('#billing_child_name').val().trim();
        if (!/^[А-Яа-яёЁ\s]+$/.test(childName) || childName.split(' ').length < 3) {
            $('#billing_child_name_error').text('Ф.И.О. ребенка должно содержать только кириллицу и быть в формате "Фамилия Имя Отчество".');
            isValid = false;
        } else {
            $('#billing_child_name_error').text('');
        }

        // Валидация телефона
        const phone = $('#billing_phone').val();
        if (!/^\+7 \(\d{3}\) \d{3} \d{2} \d{2}$/.test(phone)) {
            $('#billing_phone_error').text('Неверный формат телефона.');
            isValid = false;
        } else {
            $('#billing_phone_error').text('');
        }

        // Валидация даты рождения
        const childBdate = $('#billing_wooccm11').val();
        if (!childBdate) {
            $('#billing_wooccm11_error').text('Дата рождения ребенка обязательна.');
            isValid = false;
        } else {
            $('#billing_wooccm11_error').text('');
        }

        if (!isValid) {
            e.preventDefault(); // Предотвращаем отправку формы при ошибках
        }
    });
});
